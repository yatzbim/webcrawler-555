package edu.upenn.cis455.storage;

import java.io.Serializable;
import java.util.HashSet;

public class SetWrapper extends HashSet<String> implements Serializable {

	private static final long serialVersionUID = -814337735389764947L;

}
