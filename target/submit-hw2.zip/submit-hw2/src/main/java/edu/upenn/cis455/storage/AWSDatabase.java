package edu.upenn.cis455.storage;

public class AWSDatabase {

}
